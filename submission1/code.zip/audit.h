#ifndef AUDIT_H
#define AUDIT_H

int setupAudit();
void logChanges();

#endif // AUDIT_H
