#ifndef LOGGER_H
#define LOGGER_H

void pipeSyslogToFile(int[2]);

#endif // LOGGER_H
