#ifndef PERMISSIONS_H
#define PERMISSIONS_H

void changeMode(char *, char *);

#endif // PERMISSIONS_H
